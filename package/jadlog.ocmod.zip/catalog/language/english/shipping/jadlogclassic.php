<?php
$_['text_title']        = 'Jadlog - Entrega no endereço informado';
$_['text_subtitledpd']  = 'Jadlog - Entrega no endereço informado';
$_['text_dpdblock']     = 'Jadlog - Entrega no endereço informado'; 
?>