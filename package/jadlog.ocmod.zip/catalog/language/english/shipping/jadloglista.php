<?php
$_['text_subtitle'] = 'Jadlog - Retire em um ponto Pickup</strong><br/><br/>receba em um dos nossos pontos de Pickup';
$_['text_header']   = 'Por favor, escolha seu ponto de Pickup na lista abaixo';
$_['text_details']  = 'Mais detalhes';
?>