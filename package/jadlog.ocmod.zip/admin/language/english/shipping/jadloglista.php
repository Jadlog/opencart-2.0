<?php
$_['heading_title']              = 'Jadlog - Retire em um ponto Pickup';
$_['text_edit']                  = 'Configuração';
$_['text_success']               = 'Sucesso: Você modificou a configuração Jadlog - Retire em um ponto Pickup!';
$_['text_activate']              = 'Enable / Disable this module';
$_['entry_status']               = 'Status';
$_['error_permission']           = 'Warning: Você não tem permissão para modificar a configuração Jadlog - Retire em um ponto Pickup!';
?>